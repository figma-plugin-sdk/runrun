
import { suite, test } from 'rfr';
import { Square } from './square';

suite('Square', () => {
  test('should initialize properly', (context) => {
    const square = new Square(10, 0, 0);
    context.failUnlessEqual(square.size, 10);
  });
  // ... Further tests ...
});

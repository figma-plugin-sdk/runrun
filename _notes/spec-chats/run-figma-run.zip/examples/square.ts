
class Square {
  constructor(public size: number, public x: number, public y: number) {}
  splitIntoQuarters(): Square[] {
    // ... Implementation ...
  }
}

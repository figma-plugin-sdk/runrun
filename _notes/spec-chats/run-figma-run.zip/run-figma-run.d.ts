
declare namespace RFR {
  // ... (content as described above) ...
}
declare const suite: RFR.RunnableSet;
declare const test: RFR.RunnableUnit;
